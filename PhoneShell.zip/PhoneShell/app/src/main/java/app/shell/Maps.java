package app.shell;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.webkit.WebResourceResponse;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Офлайн-карты. Порядок поиска тайла: импортированные .mbtiles (растровые) → кэш приложения → сеть
 * (tile.openstreetmap.org, результат кэшируется). Кнопка «⬇» на карте докачивает тайлы текущего вида
 * (не более 200 штук за раз, с паузой) — массовое скачивание тайлов OSM запрещено их политикой.
 */
final class Maps {
    private final Context ctx;
    private final File dir;
    private final SQLiteDatabase cache;
    private final List<SQLiteDatabase> packs = new ArrayList<>();
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final AtomicBoolean running = new AtomicBoolean(false);
    private volatile int done, total;
    private final File cacheFile;

    Maps(Context c) {
        ctx = c;
        dir = new File(c.getFilesDir(), "maps");
        dir.mkdirs();
        cacheFile = new File(c.getFilesDir(), "tilecache.db");
        cache = SQLiteDatabase.openOrCreateDatabase(cacheFile, null);
        cache.execSQL("CREATE TABLE IF NOT EXISTS t(z INTEGER,x INTEGER,y INTEGER,d BLOB,PRIMARY KEY(z,x,y))");
        reloadPacks();
    }

    synchronized void reloadPacks() {
        for (SQLiteDatabase d : packs) {
            try { d.close(); } catch (Exception ignored) {}
        }
        packs.clear();
        File[] fs = dir.listFiles();
        if (fs == null) return;
        for (File f : fs) {
            if (!f.getName().endsWith(".mbtiles")) continue;
            try {
                packs.add(SQLiteDatabase.openDatabase(f.getPath(), null, SQLiteDatabase.OPEN_READONLY));
            } catch (Exception ignored) {
            }
        }
    }

    int packCount() { return packs.size(); }

    long cacheBytes() { return cacheFile.length(); }

    /** Импорт растрового .mbtiles. Возвращает false, если это не MBTiles. */
    boolean importPack(InputStream in) {
        File f = new File(dir, "pack-" + System.currentTimeMillis() + ".mbtiles");
        try {
            FileOutputStream o = new FileOutputStream(f);
            try {
                byte[] b = new byte[65536];
                int n;
                while ((n = in.read(b)) > 0) o.write(b, 0, n);
            } finally {
                o.close();
                in.close();
            }
            SQLiteDatabase t = SQLiteDatabase.openDatabase(f.getPath(), null, SQLiteDatabase.OPEN_READONLY);
            Cursor c = t.rawQuery("SELECT count(*) FROM tiles", null);
            c.close();
            t.close();
            reloadPacks();
            return true;
        } catch (Exception e) {
            f.delete();
            return false;
        }
    }

    synchronized void clearCache() {
        try {
            cache.execSQL("DELETE FROM t");
            cache.execSQL("VACUUM");
        } catch (Exception ignored) {
        }
    }

    // ---------- тайлы ----------

    private synchronized byte[] local(int z, int x, int y) {
        for (SQLiteDatabase db : packs) {
            try {
                Cursor c = db.rawQuery("SELECT tile_data FROM tiles WHERE zoom_level=? AND tile_column=? AND tile_row=?",
                        new String[]{"" + z, "" + x, "" + ((1 << z) - 1 - y)});
                try {
                    if (c.moveToFirst()) return c.getBlob(0);
                } finally {
                    c.close();
                }
            } catch (Exception ignored) {
            }
        }
        try {
            Cursor c = cache.rawQuery("SELECT d FROM t WHERE z=? AND x=? AND y=?", new String[]{"" + z, "" + x, "" + y});
            try {
                if (c.moveToFirst()) return c.getBlob(0);
            } finally {
                c.close();
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private byte[] online(int z, int x, int y) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL("https://tile.openstreetmap.org/" + z + "/" + x + "/" + y + ".png").openConnection();
            c.setConnectTimeout(6000);
            c.setReadTimeout(6000);
            c.setRequestProperty("User-Agent", "PhoneShell/1.0 (personal offline cache; Android)");
            if (c.getResponseCode() != 200) return null;
            byte[] b = Io.readAll(c.getInputStream(), 300000);
            if (b.length == 0) return null;
            ContentValues v = new ContentValues();
            v.put("z", z);
            v.put("x", x);
            v.put("y", y);
            v.put("d", b);
            synchronized (this) {
                cache.insertWithOnConflict("t", null, v, SQLiteDatabase.CONFLICT_REPLACE);
            }
            return b;
        } catch (Exception e) {
            return null;
        }
    }

    private byte[] tile(int z, int x, int y, boolean allowOnline) {
        if (z < 0 || z > 19 || x < 0 || y < 0 || x >= (1 << z) || y >= (1 << z)) return null;
        byte[] b = local(z, x, y);
        return b != null || !allowOnline ? b : online(z, x, y);
    }

    // ---------- запросы страницы maps.local ----------

    WebResourceResponse handle(Uri u) {
        String p = u.getPath() == null ? "/" : u.getPath();
        if (p.equals("/") || p.equals("/index.html")) return Local.asset(ctx, "map.html", "text/html");
        if (p.startsWith("/t/")) {
            String[] a = p.substring(3).split("/");
            try {
                byte[] b = tile(Integer.parseInt(a[0]), Integer.parseInt(a[1]), Integer.parseInt(a[2]), true);
                if (b == null) return Local.notFound();
                String mime = b.length > 2 && (b[0] & 0xFF) == 0xFF && (b[1] & 0xFF) == 0xD8 ? "image/jpeg" : "image/png";
                return new WebResourceResponse(mime, null, 200, "OK", new HashMap<String, String>(), new ByteArrayInputStream(b));
            } catch (Exception e) {
                return Local.notFound();
            }
        }
        if (p.equals("/api/prefetch")) {
            prefetch(u.getQueryParameter("r"));
            return Local.text("text/plain", "ok");
        }
        if (p.equals("/api/status")) {
            return Local.text("application/json", "{\"done\":" + done + ",\"total\":" + total + "}");
        }
        return Local.notFound();
    }

    private void prefetch(String ranges) {
        if (ranges == null || !running.compareAndSet(false, true)) return;
        final List<int[]> list = new ArrayList<>();
        try {
            for (String part : ranges.split(";")) {
                String[] q = part.split(",");
                int z = Integer.parseInt(q[0]), x0 = Integer.parseInt(q[1]), x1 = Integer.parseInt(q[2]),
                        y0 = Integer.parseInt(q[3]), y1 = Integer.parseInt(q[4]);
                for (int x = x0; x <= x1; x++)
                    for (int y = y0; y <= y1; y++)
                        if (list.size() < 200) list.add(new int[]{z, x, y});
            }
        } catch (Exception e) {
            running.set(false);
            return;
        }
        done = 0;
        total = list.size();
        exec.execute(() -> {
            try {
                for (int[] t : list) {
                    if (tile(t[0], t[1], t[2], false) == null) {
                        online(t[0], t[1], t[2]);
                        Thread.sleep(300);
                    }
                    done++;
                }
            } catch (InterruptedException ignored) {
            } finally {
                done = total;
                running.set(false);
            }
        });
    }
}
