package app.shell;

import android.content.Context;
import android.webkit.WebResourceResponse;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;

/** Ответы для внутренних страниц (карты, QR), которые отдаются без сети. */
final class Local {
    private Local() {}

    static WebResourceResponse asset(Context c, String name, String mime) {
        try {
            return new WebResourceResponse(mime, "utf-8", c.getAssets().open(name));
        } catch (Exception e) {
            return notFound();
        }
    }

    static WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    static WebResourceResponse text(String mime, String s) {
        return new WebResourceResponse(mime, "utf-8", new ByteArrayInputStream(s.getBytes(StandardCharsets.UTF_8)));
    }
}
